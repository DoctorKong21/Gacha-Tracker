export interface CountdownParts {
  hours: number;
  minutes: number;
  seconds: number;
  totalMs: number;
}

interface ZonedParts {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  second: number;
}

function getZonedParts(date: Date, timezone: string): ZonedParts {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: timezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date);

  const value = (type: Intl.DateTimeFormatPartTypes) => {
    const part = parts.find(p => p.type === type);
    if (!part) throw new Error(`Missing ${type} while reading ${timezone}`);
    return Number(part.value);
  };

  return {
    year: value('year'),
    month: value('month'),
    day: value('day'),
    hour: value('hour') === 24 ? 0 : value('hour'),
    minute: value('minute'),
    second: value('second'),
  };
}

function parseResetTime(dailyReset: string): [number, number, number] {
  const match = /^(\d{1,2}):(\d{2})(?::(\d{2}))?$/.exec(dailyReset);
  if (!match) throw new Error(`Invalid daily reset time: ${dailyReset}`);
  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  const seconds = Number(match[3] ?? 0);
  if (hours > 23 || minutes > 59 || seconds > 59) throw new Error(`Invalid daily reset time: ${dailyReset}`);
  return [hours, minutes, seconds];
}

/** Convert a wall-clock time in an IANA timezone to its UTC instant. */
function zonedTimeToUtc(
  year: number,
  month: number,
  day: number,
  hour: number,
  minute: number,
  second: number,
  timezone: string,
): number {
  const targetAsUtc = Date.UTC(year, month - 1, day, hour, minute, second);
  let candidate = targetAsUtc;

  // Resolve the timezone offset iteratively. Unlike adding a fixed 24 hours,
  // this remains correct when the timezone enters or leaves daylight saving.
  for (let i = 0; i < 5; i++) {
    const observed = getZonedParts(new Date(candidate), timezone);
    const observedAsUtc = Date.UTC(
      observed.year, observed.month - 1, observed.day,
      observed.hour, observed.minute, observed.second,
    );
    const adjustment = targetAsUtc - observedAsUtc;
    if (adjustment === 0) break;
    candidate += adjustment;
  }

  return candidate;
}

/** Milliseconds until the next reset in the game's own timezone. */
export function getNextResetMs(timezone: string, dailyReset: string, now = new Date()): number {
  const [resetHour, resetMinute, resetSecond] = parseResetTime(dailyReset);
  const localNow = getZonedParts(now, timezone);
  const currentClock = localNow.hour * 3600 + localNow.minute * 60 + localNow.second;
  const resetClock = resetHour * 3600 + resetMinute * 60 + resetSecond;

  // Choose today's reset if it is still ahead; otherwise choose tomorrow's.
  const dayOffset = currentClock < resetClock ? 0 : 1;
  const targetDate = new Date(Date.UTC(localNow.year, localNow.month - 1, localNow.day + dayOffset));
  const targetMs = zonedTimeToUtc(
    targetDate.getUTCFullYear(),
    targetDate.getUTCMonth() + 1,
    targetDate.getUTCDate(),
    resetHour,
    resetMinute,
    resetSecond,
    timezone,
  );

  const remaining = targetMs - now.getTime();
  // Defensive fallback for an unusual timezone transition at the reset time.
  return remaining > 0 ? remaining : 1;
}

/** The game's current daily period key (YYYY-MM-DD), not the viewer's UTC date. */
export function getGamePeriodDate(timezone: string, dailyReset: string, now = new Date()): string {
  const [resetHour, resetMinute, resetSecond] = parseResetTime(dailyReset);
  const localNow = getZonedParts(now, timezone);
  const currentClock = localNow.hour * 3600 + localNow.minute * 60 + localNow.second;
  const resetClock = resetHour * 3600 + resetMinute * 60 + resetSecond;
  const dayOffset = currentClock < resetClock ? -1 : 0;
  const periodDate = new Date(Date.UTC(localNow.year, localNow.month - 1, localNow.day + dayOffset));
  return [
    periodDate.getUTCFullYear(),
    String(periodDate.getUTCMonth() + 1).padStart(2, '0'),
    String(periodDate.getUTCDate()).padStart(2, '0'),
  ].join('-');
}

export function msToCountdown(ms: number): CountdownParts {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return { hours, minutes, seconds, totalMs: ms };
}

export function getLocalResetTime(timezone: string, dailyReset: string): string {
  const ms = getNextResetMs(timezone, dailyReset);
  const resetDate = new Date(Date.now() + ms);
  return resetDate.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
}

export function formatCountdown(parts: CountdownParts): string {
  const h = String(parts.hours).padStart(2, '0');
  const m = String(parts.minutes).padStart(2, '0');
  const s = String(parts.seconds).padStart(2, '0');
  return `${h}:${m}:${s}`;
}
