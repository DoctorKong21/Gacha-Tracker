# Publicar tu GachaDailyTracker en Internet (guía en español)

Esta copia conserva el frontend Next.js y la API Express/PostgreSQL del proyecto original.
Incluye un ajuste visual en las tarjetas: cuando un juego está marcado como `Done`, la cuenta regresiva aparece en la misma línea, junto al estado.

## Arquitectura elegida para comenzar sin costo

- **GitHub**: guarda el código fuente privado o público.
- **Vercel Hobby**: publica el frontend web (Next.js).
- **Render Free**: ejecuta la API (Node.js/Express).
- **Neon Free**: aloja PostgreSQL. Se usa Neon en vez de Render Postgres Free porque las bases de datos gratuitas de Render caducan a los 30 días.

Limitaciones a tener presentes:
- El backend gratuito de Render se duerme después de 15 minutos sin tráfico. La primera petición después de dormir puede tardar alrededor de un minuto en responder.
- Mientras Render esté dormido, los procesos programados del backend (por ejemplo, avisos push y correos programados) no pueden ejecutarse puntualmente. Los contadores de reinicio del navegador siguen calculándose en la página.
- Neon Free tiene límites de uso y almacenamiento. Revisa el panel de Neon para ver el consumo real.
- Para un backend siempre activo, más adelante se puede pasar el API a un plan de pago como Railway Hobby; no es necesario para probar la web.

## 1. Crear tu copia en GitHub

1. Extrae esta carpeta en tu PC.
2. Crea un repositorio nuevo en https://github.com/new. Puedes llamarlo `gacha-daily-tracker-personal` y dejarlo **Private**.
3. Instala Git for Windows si aún no lo tienes: https://git-scm.com/downloads/win
4. Abre PowerShell dentro de la carpeta `GachaDailyTracker-Web` y ejecuta estos comandos, reemplazando la URL por la de tu repositorio:

```powershell
git init
git add .
git commit -m "Prepare GachaDailyTracker for web deployment"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/gacha-daily-tracker-personal.git
git push -u origin main
```

No subas archivos `.env`, `.env.local`, contraseñas, claves ni tokens. El `.gitignore` del proyecto excluye los archivos de entorno.

## 2. Crear la base de datos en Neon

1. Crea una cuenta en https://neon.com/ y un proyecto PostgreSQL.
2. En el panel de Neon, abre **SQL Editor**.
3. Abre el archivo `database/init/01-schema.sql` de este repositorio, copia todo su contenido y ejecútalo en el SQL Editor. Esto crea las tablas y columnas que espera esta versión.
4. En **Connect**, copia la cadena de conexión PostgreSQL. Usa la cadena recomendada por Neon (preferentemente la opción pooled). Guárdala para el siguiente paso; no la compartas públicamente.

El API importa el catálogo inicial de juegos automáticamente al primer arranque, usando `data/game-data-backup.json` incluido en el repositorio.

## 3. Publicar el backend en Render

1. Crea una cuenta en https://render.com/.
2. En Render elige **New → Blueprint** y conecta tu cuenta de GitHub.
3. Selecciona el repositorio `gacha-daily-tracker-personal`. Render detectará `render.yaml`.
4. Durante la configuración introduce:
   - `DATABASE_URL`: la cadena de conexión que copiaste de Neon.
   - `FRONTEND_URL`: temporalmente `https://example.vercel.app`. Luego se reemplaza por la dirección real de Vercel.
   - Render generará `JWT_SECRET`, `PASSWORD_PEPPER` y `REGISTRATION_TOKEN` automáticamente.
5. Crea el Blueprint y espera a que el servicio termine el primer deploy.
6. Copia la URL pública del servicio, por ejemplo `https://gacha-daily-tracker-api.onrender.com`.
7. Comprueba `https://TU-API.onrender.com/gdt/health`. La respuesta debe mostrar `status: "OK"` y `database.status: "healthy"`.
8. En Render → servicio API → **Environment**, copia el valor de `REGISTRATION_TOKEN`. No lo publiques ni lo pegues en este chat.

## 4. Publicar el frontend en Vercel

1. Crea una cuenta en https://vercel.com/ con GitHub.
2. Pulsa **Add New → Project** e importa `gacha-daily-tracker-personal`.
3. En **Root Directory**, selecciona `frontend`.
4. Vercel debería detectar Next.js automáticamente. Deja los comandos predeterminados.
5. Añade estas variables de entorno:
   - `NEXT_PUBLIC_API_URL` = la URL del backend de Render, sin `/` al final.
   - `REGISTRATION_TOKEN` = exactamente el mismo valor configurado en Render.
6. Pulsa **Deploy**. Vercel entregará una URL pública `*.vercel.app`.

## 5. Conectar ambos servicios

1. Vuelve a Render → servicio API → **Environment**.
2. Cambia `FRONTEND_URL` por la URL exacta de Vercel, por ejemplo `https://gacha-daily-tracker-personal.vercel.app`.
3. Guarda los cambios y realiza un redeploy si Render no lo hace automáticamente.
4. En Vercel, verifica que `NEXT_PUBLIC_API_URL` siga apuntando a la URL correcta de Render.

## 6. Cuentas y sincronización entre dispositivos

- El modo anónimo guarda la lista en el almacenamiento local del navegador: no se comparte automáticamente entre PC y celular.
- Para sincronizar una cuenta entre dispositivos, el registro requiere correo de verificación. Para habilitarlo en producción, crea una cuenta en https://resend.com/, verifica un dominio/remitente que controles y añade `RESEND_API_KEY` y `RESEND_FROM_EMAIL` a las variables del servicio API en Render.
- Sin configurar Resend, el sitio puede abrirse y el modo anónimo funciona, pero el correo de verificación no se enviará; no dependas de cuentas nuevas hasta configurar el remitente.

## 7. Comprobar la publicación

- Abre la URL `*.vercel.app` desde el PC y desde el celular.
- Revisa que cargue el catálogo de juegos.
- Abre la URL `https://TU-API.onrender.com/gdt/health` y comprueba la conexión a PostgreSQL.
- Marca un juego como completado: `Done` y el tiempo restante deben quedar en la misma línea.
- Crea una cuenta solo después de configurar el envío de correo si deseas sincronizar datos.

## Enlaces oficiales

- GitHub: https://github.com/new
- Render Blueprint: https://render.com/docs/blueprint-spec
- Render límites gratuitos: https://render.com/docs/free
- Neon: https://neon.com/
- Vercel: https://vercel.com/new
- Vercel Root Directory (monorepos): https://vercel.com/docs/projects/project-configuration#root-directory
- Resend: https://resend.com/

La aplicación conserva la licencia GPL-3.0 del repositorio de origen. Mantén el archivo `LICENSE` y los avisos de atribución al redistribuir modificaciones.
