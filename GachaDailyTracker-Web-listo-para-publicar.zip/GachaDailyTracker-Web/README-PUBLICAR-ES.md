# Publicar GachaDailyTracker en Internet

Lee primero [DEPLOY-WEB-ES.md](./DEPLOY-WEB-ES.md). La configuración incluida usa Vercel para `frontend/`, Render para la API Express y Neon para PostgreSQL.

El servicio gratuito de Render puede dormir por inactividad. La cuenta anónima guarda datos localmente en cada navegador; para sincronizar entre PC y celular se necesita una cuenta verificada y configurar un remitente de correo con Resend.
